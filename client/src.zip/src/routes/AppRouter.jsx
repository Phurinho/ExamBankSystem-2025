import React from 'react'
import { Routes, Route } from 'react-router-dom'
import MainLayout from '../layouts/MainLayout.jsx'
import Home from '../pages/Auth/Home.jsx'
import InstructorDashboard from '../pages/Instructor/Dashboard.jsx'
import InstructorProfile from '../pages/Instructor/Profile.jsx'
import CreateExam from '../pages/Instructor/CreateExam.jsx'
import StudentDashboard from '../pages/Student/Dashboard.jsx'
import Exam from '../pages/Student/Exam.jsx'
import NotFound from '../pages/NotFound.jsx'
import ProtectedRoute from './ProtectedRoute.jsx'

export default function AppRouter() {
  return (
    <Routes>
      {/* Public */}
      <Route element={<MainLayout />}>
        <Route path="/" element={<Home />} />
      </Route>

      {/* Instructor */}
      <Route element={<ProtectedRoute role="instructor" />}>
        <Route path="/instructor/dashboard" element={<InstructorDashboard />} />
        <Route path="/instructor/profile" element={<InstructorProfile />} />
        <Route path="/instructor/create" element={<CreateExam />} />
      </Route>

      {/* Student */}
      <Route element={<ProtectedRoute role="student" />}>
        <Route path="/student/dashboard" element={<StudentDashboard />} />
        <Route path="/exam/:id" element={<Exam />} />
      </Route>

      {/* Fallback */}
      <Route path="*" element={<NotFound />} />
    </Routes>
  )
}
