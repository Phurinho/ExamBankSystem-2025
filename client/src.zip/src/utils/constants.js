export const ROLES = {
  STUDENT: 'student',
  INSTRUCTOR: 'instructor',
}
