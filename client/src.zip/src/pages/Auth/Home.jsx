import React, { useState } from 'react'
import { ROLES } from '../../utils/constants'
import Modal from 'react-bootstrap/Modal'
import Button from 'react-bootstrap/Button'
import 'bootstrap/dist/css/bootstrap.min.css'

export default function Home() {
  const [loginData, setLoginData] = useState({ username: '', password: '' })
  const [registerData, setRegisterData] = useState({
    username: '',
    email: '',
    password: '',
    department: '',
    role: ROLES.STUDENT,
    studentId: '',
  })
  const [showRegister, setShowRegister] = useState(false)

  const handleLoginChange = (e) => {
    const { name, value } = e.target
    setLoginData(prev => ({ ...prev, [name]: value }))
  }

  const handleRegisterChange = (e) => {
    const { name, value } = e.target
    setRegisterData(prev => ({ ...prev, [name]: value }))
  }

  const handleRoleChange = (role) => {
    setRegisterData(prev => ({
      ...prev,
      role,
      studentId: role === ROLES.STUDENT ? prev.studentId : ''
    }))
  }

  const handleLoginSubmit = async (e) => {
  e.preventDefault()
  console.log('Logging in with:', loginData)
  try {
    const res = await fetch('http://localhost:3000/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(loginData)
    })

    console.log('Response status:', res.status)
    const data = await res.json()
    console.log('Response data:', data)

    if (res.ok) {
      localStorage.setItem('token', data.token)
      localStorage.setItem('role', data.user.role)
      if (data.user.role === 'instructor') {
        navigate('/instructor/dashboard')
      } else if (data.user.role === 'student') {
        navigate('/student/dashboard')
      } else {
        alert('Unknown role')
      }
    } else {
      alert(data.message || 'Login failed')
    }
  } catch (err) {
    alert('Login error')
    console.error(err)
  }
}


  const handleRegisterSubmit = async (e) => {
    e.preventDefault()
    try {
      const res = await fetch('http://localhost:3000/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(registerData)
      })
      const data = await res.json()
      if (res.ok) {
        alert('Register successfully!')
        setShowRegister(false)
      } else {
        alert(data.message || 'Register failed')
      }
    } catch (err) {
      console.error(err)
      alert('Error during register')
    }
  }

  return (
    <div className="bg-light min-vh-100 d-flex flex-column justify-content-start align-items-center pt-5">
    <h1 className="fw-bold mb-4 text-center mt-3">Welcome to Online Exam Web page</h1>


      {/* Login Form Centered */}
       <form className="p-4 bg-white rounded shadow-sm" style={{ width: '320px' }} onSubmit={handleLoginSubmit}>
        <h5 className="text-center mb-3">Login</h5>
        <div className="mb-3">
          <label className="form-label">Username</label>
          <input
            className="form-control"
            type="text"
            name="username"
            value={loginData.username}
            onChange={handleLoginChange}
            required
            autoComplete="username"
          />
        </div>
        <div className="mb-3">
          <label className="form-label">Password</label>
          <input
            className="form-control"
            type="password"
            name="password"
            value={loginData.password}
            onChange={handleLoginChange}
            required
            autoComplete="current-password"
          />
        </div>
        <div className="text-center mb-3">
          <small className="text-muted">Don't have any account? <span role="button" className="text-primary" onClick={() => setShowRegister(true)}>Register here</span></small>
        </div>
        <button className="btn btn-dark w-100" type="submit">Login</button>
      </form>

      {/* Register Modal */}
      <Modal show={showRegister} onHide={() => setShowRegister(false)} centered>
        <Modal.Header closeButton>
          <Modal.Title>Register</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <form onSubmit={handleRegisterSubmit}>
            <div className="mb-2">
              <label className="form-label">Username</label>
              <input className="form-control" name="username" value={registerData.username} onChange={handleRegisterChange} required autoComplete="username" />
            </div>
            <div className="mb-2">
              <label className="form-label">Email Address</label>
              <input type="email" className="form-control" name="email" value={registerData.email} onChange={handleRegisterChange} required autoComplete="email" />
            </div>
            <div className="mb-2">
              <label className="form-label">Password</label>
              <input type="password" className="form-control" name="password" value={registerData.password} onChange={handleRegisterChange} required autoComplete="new-password" />
            </div>
            <div className="mb-2">
              <label className="form-label">Department</label>
              <input className="form-control" name="department" value={registerData.department} onChange={handleRegisterChange} />
            </div>
            <div className="mb-2">
              <label className="form-label d-block">Role</label>
              <div className="btn-group w-100">
                <button type="button" className={`btn ${registerData.role === ROLES.STUDENT ? 'btn-secondary' : 'btn-outline-secondary'}`} onClick={() => handleRoleChange(ROLES.STUDENT)}>Student</button>
                <button type="button" className={`btn ${registerData.role === ROLES.INSTRUCTOR ? 'btn-secondary' : 'btn-outline-secondary'}`} onClick={() => handleRoleChange(ROLES.INSTRUCTOR)}>Instructor</button>
              </div>
            </div>
            {registerData.role === ROLES.STUDENT && (
              <div className="mb-2">
                <label className="form-label">Student ID</label>
                <input className="form-control" name="studentId" value={registerData.studentId} onChange={handleRegisterChange} required />
              </div>
            )}
            <button className="btn btn-dark w-100 mt-3" type="submit">Register</button>
          </form>
        </Modal.Body>
      </Modal>
    </div>
  )
}
