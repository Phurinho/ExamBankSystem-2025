import React from 'react'

export default function Exam() {
  return (
    <div className="container py-5">
      <h2 className="text-center">Examination Page</h2>
      <p className="text-muted text-center">(Under construction)</p>
    </div>
  )
}
