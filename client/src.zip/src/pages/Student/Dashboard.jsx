import React from 'react'
export default function Dashboard() {
  return (
    <div className="container py-5">
      <h2 className="text-center">Student Dashboard</h2>
    </div>
  )
}
