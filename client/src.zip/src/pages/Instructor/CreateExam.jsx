import React from 'react'

export default function CreateExam() {
  return (
    <div className="container py-5">
      <h2 className="text-center">Create Exam Page</h2>
      <p className="text-muted text-center">(Under construction)</p>
    </div>
  )
}
