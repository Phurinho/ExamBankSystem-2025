import React, { useEffect, useState } from 'react'
import { FaEdit, FaTrash, FaEye } from 'react-icons/fa'
import axios from 'axios'

export default function InstructorDashboard() {
  const [exams, setExams] = useState([])
  const [filterStatus, setFilterStatus] = useState({ publish: true, draft: true })
  const [searchText, setSearchText] = useState('')

  const token = localStorage.getItem('token')

  useEffect(() => {
    axios.get('http://localhost:3000/api/instructor/dashboard', {
      headers: { Authorization: `Bearer ${token}` }
    }).then(res => {
      setExams(res.data.exams || [])
    }).catch(err => {
      console.error('Load exams failed:', err)
    })
  }, [])

  const filteredExams = exams.filter(exam => {
    const matchStatus =
      (filterStatus.publish && exam.Status === 'published') ||
      (filterStatus.draft && exam.Status === 'draft')
    const matchSearch = exam.ExamName.toLowerCase().includes(searchText.toLowerCase())
    return matchStatus && matchSearch
  })

  return (
    <div className="container py-5">
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h2>Welcome Back Mr. <span className="text-primary">Instructor</span></h2>
        <div className="d-flex gap-3">
          <button className="btn btn-outline-secondary">InstructorProfile</button>
          <button className="btn btn-outline-dark">CreateExam</button>
          <button className="btn btn-outline-danger">Logout</button>
        </div>
      </div>

      <div className="card p-3 mb-4">
        <div className="row g-3 align-items-center">
          <div className="col-auto">
            <label className="form-label fw-bold mb-0">Status:</label>
          </div>
          <div className="col-auto form-check">
            <input className="form-check-input" type="checkbox" id="chkPublish"
              checked={filterStatus.publish}
              onChange={() => setFilterStatus(prev => ({ ...prev, publish: !prev.publish }))} />
            <label className="form-check-label ms-1" htmlFor="chkPublish">✅ Publish</label>
          </div>
          <div className="col-auto form-check">
            <input className="form-check-input" type="checkbox" id="chkDraft"
              checked={filterStatus.draft}
              onChange={() => setFilterStatus(prev => ({ ...prev, draft: !prev.draft }))} />
            <label className="form-check-label ms-1" htmlFor="chkDraft">🟡 Draft</label>
          </div>
          <div className="col">
            <input
              className="form-control"
              type="text"
              placeholder="Search Exam Name..."
              value={searchText}
              onChange={(e) => setSearchText(e.target.value)}
            />
          </div>
          <div className="col-auto">
            <button className="btn btn-dark">Apply Filter</button>
          </div>
        </div>
      </div>

      <table className="table table-bordered table-hover text-center align-middle">
        <thead className="table-dark">
          <tr>
            <th>Exam</th>
            <th>Course</th>
            <th>Topic</th>
            <th>Status</th>
            <th>View</th>
            <th>Control</th>
          </tr>
        </thead>
        <tbody>
          {filteredExams.length > 0 ? (
            filteredExams.map((exam, idx) => (
              <tr key={idx}>
                <td>{exam.ExamName}</td>
                <td>{exam.CourseName}</td>
                <td>{exam.TopicName}</td>
                <td>{exam.Status}</td>
                <td>
                  <button className="btn btn-sm btn-secondary">
                    <FaEye className="me-1" /> View
                  </button>
                </td>
                <td>
                  <button className="btn btn-sm btn-outline-primary me-2">
                    <FaEdit />
                  </button>
                  <button className="btn btn-sm btn-outline-danger">
                    <FaTrash />
                  </button>
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan="6" className="text-muted">No exams found</td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  )
}
